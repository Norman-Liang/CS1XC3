/**
 * @file course.c
 * @author Sharmin Ahmed
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include "student.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Adds a student to the course's students list, and 
 * add one to total number of students in the course
 * 
 * @param course 
 * @param student 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // If the enrolled student is the first student of the course
    // allocate one Student's space in the students list
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      // Reallocate more space if the student added is not the first student
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * Prints a course in a list incl. name, code, total_students, students
 * 
 * @param course the course to be printed
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // This goes through every student in the students list and 
  // prints the student information and each of their grades
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * Returns the pointer of the student with the highest grade
 * 
 * @param course 
 * @return Student* the student with the highest grade
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
 // This goes through every student in the class list and 
 // saves the current student with the highest average in 
 // student
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * Returns a list of students that are passing a specified course
 * 
 * @param course 
 * @param total_passing the number of students passing the course 
 * @return Student* A list of students that are passing
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Search for the number of student with an average greater or equal to 50
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Allocate space for the number of students passing
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // Add each passing student to the passing list
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}